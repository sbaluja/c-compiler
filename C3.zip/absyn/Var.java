package absyn;

abstract public class Var extends Absyn {
    public String name;
}
