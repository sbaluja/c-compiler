package absyn;

abstract public class Dec extends Absyn {
    public NameTy type;
    public boolean isParam = false;
}
