package absyn;

abstract public class Exp extends Absyn {
    public int type;
    public int tempAddr;
    public boolean isAddr = false;
}
